package com.donor.auth.donor_auth_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DonorAuthenticationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
