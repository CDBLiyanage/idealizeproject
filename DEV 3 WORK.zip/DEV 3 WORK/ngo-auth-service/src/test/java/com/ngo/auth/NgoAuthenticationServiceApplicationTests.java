package com.ngo.auth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NgoAuthenticationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
